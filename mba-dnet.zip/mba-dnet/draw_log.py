import matplotlib.pyplot as plt
import os
import numpy as np

fi_1 = open('./DINO3/k1-20-5x5/log.txt', 'r', encoding='utf-8')  # 1、读取路径,改为自己的路径
fi_2 = open('./DINO3/k2-20-5x5/log.txt', 'r', encoding='utf-8')  # 1、读取路径,改为自己的路径
fi_3 = open('./DINO3/k3-20-5x5/log.txt', 'r', encoding='utf-8')  # 1、读取路径,改为自己的路径
fi_5 = open('./DINO3/k5-20-5x5/log.txt', 'r', encoding='utf-8')  # 1、读取路径,改为自己的路径

iters_1 = int('12')  # 2、自己估计下坐标轴x,这里是总迭代次数
iters_2 = int('12')
iters_3 = int('12')  # 2、自己估计下坐标轴x,这里是总迭代次数
iters_5 = int('12')

lines1 = fi_1.readlines()
lines2 = fi_2.readlines()
lines3 = fi_3.readlines()
lines5 = fi_5.readlines()

train_total_loss_K1 = []
train_loss_bbox_K1 = []
APbbox_K1 = []
AP50_K1 = []

train_total_loss_K2 = []
train_loss_bbox_K2 = []
APbbox_K2 = []
AP50_K2 = []

train_total_loss_K3 = []
train_loss_bbox_K3 = []
APbbox_K3 = []
AP50_K3 = []

train_total_loss_K5 = []
train_loss_bbox_K5 = []
APbbox_K5 = []
AP50_K5 = []


# conf_loss = []
# cls_loss = []
for line in lines1:
    if ', "train_loss": ' in line:
        # print(line)
        line10 = line.split(', "train_loss": ')[-1].split(', "')[0]  # 利用固定字符段分割
        line11 = line.split(', "train_loss_bbox": ')[-1].split(', "train_loss_giou":')[0]
        line12 = line.split(', "test_coco_eval_bbox": [')[-1].split(', ')[0]
        import json
        data = line
        data_dict = json.loads(data)
        line13 = data_dict["test_coco_eval_bbox"][1]
        # line3 = line.split('conf_loss: ')[-1].split(', cls_loss:')[0]
        # line4 = line.split('cls_loss: ')[-1].split(', lr:')[0]
        train_total_loss_K1.append(float(line10))
        train_loss_bbox_K1.append(float(line11))
        APbbox_K1.append(float(line12))
        AP50_K1.append(float(line13))
        # conf_loss.append(float(line3))
        # cls_loss.append(float(line4))
        print('-----------', line10, line11, line12)
        # break

for line in lines2:
    if ', "train_loss": ' in line:
        # print(line)
        line20 = line.split(', "train_loss": ')[-1].split(', "')[0]  # 利用固定字符段分割
        line21 = line.split(', "train_loss_bbox": ')[-1].split(', "train_loss_giou":')[0]
        line22 = line.split(', "test_coco_eval_bbox": [')[-1].split(', ')[0]
        import json
        data = line
        data_dict = json.loads(data)
        line23 = data_dict["test_coco_eval_bbox"][1]
        # line3 = line.split('conf_loss: ')[-1].split(', cls_loss:')[0]
        # line4 = line.split('cls_loss: ')[-1].split(', lr:')[0]
        train_total_loss_K2.append(float(line20))
        train_loss_bbox_K2.append(float(line21))
        APbbox_K2.append(float(line22))
        AP50_K2.append(float(line23))


        # conf_loss.append(float(line3))
        # cls_loss.append(float(line4))
        print('-----------', line20, line21, line22)
        # break

for line in lines3:
    if ', "train_loss": ' in line:
        # print(line)
        line30 = line.split(', "train_loss": ')[-1].split(', "')[0]  # 利用固定字符段分割
        line31 = line.split(', "train_loss_bbox": ')[-1].split(', "train_loss_giou":')[0]
        line32 = line.split(', "test_coco_eval_bbox": [')[-1].split(', ')[0]
        import json
        data = line
        data_dict = json.loads(data)
        line33 = data_dict["test_coco_eval_bbox"][1]
        # line3 = line.split('conf_loss: ')[-1].split(', cls_loss:')[0]
        # line4 = line.split('cls_loss: ')[-1].split(', lr:')[0]
        train_total_loss_K3.append(float(line30))
        train_loss_bbox_K3.append(float(line31))
        APbbox_K3.append(float(line32))
        AP50_K3.append(float(line33))

        # conf_loss.append(float(line3))
        # cls_loss.append(float(line4))
        print('-----------', line30, line31, line32)
        # break

for line in lines5:
    if ', "train_loss": ' in line:
        # print(line)
        line50 = line.split(', "train_loss": ')[-1].split(', "')[0]  # 利用固定字符段分割
        line51 = line.split(', "train_loss_bbox": ')[-1].split(', "train_loss_giou":')[0]
        line52 = line.split(', "test_coco_eval_bbox": [')[-1].split(', ')[0]
        import json
        data = line
        data_dict = json.loads(data)
        line53 = data_dict["test_coco_eval_bbox"][1]
        # line3 = line.split('conf_loss: ')[-1].split(', cls_loss:')[0]
        # line4 = line.split('cls_loss: ')[-1].split(', lr:')[0]
        train_total_loss_K5.append(float(line50))
        train_loss_bbox_K5.append(float(line51))
        APbbox_K5.append(float(line52))
        AP50_K5.append(float(line53))

        # conf_loss.append(float(line3))
        # cls_loss.append(float(line4))
        print('-----------', line50, line51, line52)
        # break

# print(len(train_total_loss))
# plt.style.use('ggplot')

plt.rc('font', family='Times New Roman', size=13)  # 全局中英文为字体“罗马字体”
# 设置坐标轴刻度向内
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
plt.figure(0, figsize=(100, 8))  # 这里修改绘制的图的大小
x1 = np.arange(0, iters_1, 1)  ################################ 自己估计下坐标轴x,这里10是源代码默认iter=10输出一次loss
x2 = np.arange(0, iters_2, 1)
x3 = np.arange(0, iters_3, 1)  ################################ 自己估计下坐标轴x,这里10是源代码默认iter=10输出一次loss
x5 = np.arange(0, iters_5, 1)

plt.subplot(1, 3, 1)
plt.plot(x1, train_total_loss_K1, color='red',linestyle = '-.', label="Total Loss_K1")
plt.plot(x2, train_total_loss_K2, color='blue',linestyle = '--', label="Total Loss_K2")
plt.plot(x3, train_total_loss_K3, color='green', linestyle = '-',label="Total Loss_K3")
plt.plot(x5, train_total_loss_K5, color='black',linestyle = ':', label="Total Loss_K4")

plt.xlabel("epoch")
plt.ylabel("Loss")
plt.grid(True)
plt.legend(loc="upper right",fontsize=10,markerscale=2,scatterpoints=1)
# plt.subplot(2, 3, 2)
# plt.plot(x1, train_loss_bbox_K1, color='black', linestyle = '-.',label="train_loss_bbox_K1")
# plt.plot(x2, train_loss_bbox_K2, color='black', linestyle = '--',label="train_loss_bbox_K2")
# plt.plot(x1, train_loss_bbox_K3, color='black',linestyle = '-', label="train_loss_bbox_K3")
# plt.plot(x2, train_loss_bbox_K5, color='black', linestyle = ':',label="train_loss_bbox_K4")
# plt.xlabel("epoch")
# plt.ylabel("Loss")
# plt.grid(True)
# plt.legend(loc="upper right", fontsize='xx-small')
plt.subplot(1, 3, 2)
plt.plot(x1, APbbox_K1, color='red', linestyle = '-.', label="APbbox_K1")
plt.plot(x2, APbbox_K2, color='blue', linestyle = '--',label="APbbox_K2")
plt.plot(x1, APbbox_K3, color='green', linestyle = '-',label="APbbox_K3")
plt.plot(x2, APbbox_K5, color='black', linestyle = ':',label="APbbox_K4")
plt.xlabel("epoch")
plt.ylabel("AP")
plt.grid(True)
plt.legend(loc="upper left",fontsize=10,markerscale=2,scatterpoints=1)

plt.subplot(1, 3, 3)
plt.plot(x1, AP50_K1, color='red', linestyle = '-.', label="AP50_K1")
plt.plot(x2, AP50_K2, color='blue', linestyle = '--',label="AP50_K2")
plt.plot(x1, AP50_K3, color='green', linestyle = '-',label="AP50_K3")
plt.plot(x2, AP50_K5, color='black', linestyle = ':',label="AP50_K4")
plt.xlabel("epoch")
plt.ylabel("AP")
plt.grid(True)
plt.legend(loc="upper left",fontsize=10,markerscale=2,scatterpoints=1)
# plt.legend(loc="upper right", fontsize='xx-small')
# plt.subplot(2, 3, 4)
# plt.plot(x, conf_loss, color='darkorange', label="conf Loss")
# plt.xlabel("Steps")
# plt.ylabel("Loss")
# plt.grid(True)
# plt.legend(loc="upper right", fontsize='xx-small')
# plt.subplot(2, 3, 5)
# plt.plot(x, cls_loss, color='darkorange', label="cls Loss")
# plt.xlabel("Steps")
# plt.ylabel("Loss")
# plt.grid(True)
# plt.legend(loc="upper right", fontsize='xx-small')
# plt.figure(figsize=(8,8), dpi=300, bbox_inches='tight')
plt.annotate("Loss", (-2, 10), xycoords='data', xytext=(-2, 10), fontsize=15)
# plt.savefig('losses.png', dpi=300, bbox_inches='tight')
# plt.legend(fontsize=14,markerscale=2,scatterpoints=1)
plt.show()